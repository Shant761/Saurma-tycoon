# Shaurma Tycoon — Web Game (CIA SOFT)

Простая бизнес-кликер игра.

## Запуск
Открыть файл index.html

## Деплой на GitHub Pages
Settings → Pages → Branch: main, Folder: root
